/**
 * NotifEngine.java - Lumen OS Notification Engine
 * Receives JSON notifications from SweetExperiencesEngine.c via UNIX socket
 * Target: /lumen-motonexus6/system/notif/NotifEngine.java
 */

package lumen.system.notif;

import java.io.*;
import java.net.Socket;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import com.google.gson.*;
import com.google.gson.annotations.SerializedName;

public class NotifEngine {
    private static final String SOCKET_PATH = "/tmp/notifengine.sock";
    private static final String NOTIF_LOG_PATH = "/lumen-motonexus6/system/notif/notif_log.txt";
    private static final String NOTIF_DATA_PATH = "/lumen-motonexus6/system/notif/notif_data.dat";
    private static final int SERVER_PORT = 0; // UNIX socket
    private static final int MAX_QUEUE_SIZE = 100;
    private static final int DISPATCH_DELAY_MS = 1000;
    
    private final BlockingQueue<Notification> notificationQueue;
    private final ExecutorService executorService;
    private final Gson gson;
    private final AtomicBoolean running;
    private ServerSocketChannel serverChannel;
    private ScheduledExecutorService scheduler;
    
    public NotifEngine() {
        this.notificationQueue = new ArrayBlockingQueue<>(MAX_QUEUE_SIZE);
        this.executorService = Executors.newCachedThreadPool();
        this.gson = new Gson();
        this.running = new AtomicBoolean(true);
        
        // Initialize directories
        initDirectories();
        loadNotificationHistory();
    }
    
    // Notification data model
    public static class Notification {
        @SerializedName("type")
        public String type;
        
        @SerializedName("message")
        public String message;
        
        @SerializedName("priority")
        public int priority;
        
        @SerializedName("timestamp")
        public long timestamp;
        
        public LocalDateTime getFormattedTime() {
            return LocalDateTime.ofEpochSecond(timestamp, 0);
        }
        
        @Override
        public String toString() {
            return String.format("[%s] %s: %s (Priority: %d)", 
                getFormattedTime().format(DateTimeFormatter.ofPattern("HH:mm:ss")),
                type.toUpperCase(), message, priority);
        }
    }
    
    private void initDirectories() {
        try {
            Files.createDirectories(Paths.get("/lumen-motonexus6/system/notif"));
            // Clean up old socket
            Files.deleteIfExists(Paths.get(SOCKET_PATH));
        } catch (IOException e) {
            System.err.println("NotifEngine: Failed to init directories: " + e.getMessage());
        }
    }
    
    public void start() {
        System.out.println("NotifEngine: Starting notification server...");
        
        try {
            // Create UNIX socket server
            serverChannel = ServerSocketChannel.open();
            serverChannel.bind(new File(SOCKET_PATH).toPath());
            serverChannel.configureBlocking(false);
            
            // Start socket listener
            executorService.submit(this::socketListenerLoop);
            
            // Start notification dispatcher
            scheduler = Executors.newScheduledThreadPool(1);
            scheduler.scheduleWithFixedDelay(
                this::dispatchNotifications, 
                0, DISPATCH_DELAY_MS, TimeUnit.MILLISECONDS
            );
            
            System.out.println("NotifEngine: Server listening on " + SOCKET_PATH);
            logEvent("NotifEngine started");
            
        } catch (IOException e) {
            System.err.println("NotifEngine: Failed to start server: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private void socketListenerLoop() {
        while (running.get()) {
            try {
                SocketChannel client = serverChannel.accept();
                if (client != null) {
                    executorService.submit(() -> handleClient(client));
                }
            } catch (IOException e) {
                if (running.get()) {
                    System.err.println("Socket listener error: " + e.getMessage());
                }
            }
        }
    }
    
    private void handleClient(SocketChannel client) {
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(client.socket().getInputStream()))) {
            
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    Notification notif = gson.fromJson(line, Notification.class);
                    if (notificationQueue.offer(notif)) {
                        System.out.println("NotifEngine: Queued - " + notif);
                    } else {
                        System.err.println("NotifEngine: Queue full, dropped: " + line);
                    }
                } catch (JsonSyntaxException e) {
                    System.err.println("NotifEngine: Invalid JSON: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Client handler error: " + e.getMessage());
        } finally {
            try {
                client.close();
            } catch (IOException ignored) {}
        }
    }
    
    private void dispatchNotifications() {
        Notification notif = notificationQueue.poll();
        if (notif != null) {
            try {
                displayNotification(notif);
                logNotification(notif);

// SQLite integration example
try (Connection conn = DriverManager.getConnection("jdbc:sqlite:notif_engine.db");
     PreparedStatement stmt = conn.prepareStatement(
         "INSERT INTO notifications (user_id, type_id, title, raw_json_payload, content_extracted, priority) " +
         "VALUES ((SELECT user_id FROM users WHERE username='system'), " +
         "(SELECT type_id FROM notification_types WHERE type_name=?), ?, ?, json_extract(?, '$.message'), ?)")) {
    
    stmt.setString(1, notif.type);
    stmt.setString(2, capitalize(notif.type) + ": " + notif.message);
    stmt.setString(3, line);
    stmt.setString(4, line);
    stmt.setInt(5, notif.priority);
    stmt.executeUpdate();
} catch (SQLException e) {
    System.err.println("DB insert failed: " + e.getMessage());
}
                saveNotificationHistory(notif);
            } catch (Exception e) {
                System.err.println("Dispatch error: " + e.getMessage());
            }
        }
    }
    
    // Display notification through Lumen OS system
    private void displayNotification(Notification notif) {
        // Priority-based display logic
        String displayType = getDisplayType(notif.priority);
        String formattedMsg = formatNotification(notif);
        
        // Lumen OS notification system integration
        lumenDisplayNotification(displayType, formattedMsg);
        
        // System notification (fallback)
        switch (notif.priority) {
            case 5: // Achievement - High visibility
                System.out.println("\u001B[32m\u001B[1m🎉 " + formattedMsg + "\u001B[0m");
                break;
            case 3: case 4: // Important
                System.out.println("\u001B[33m⭐ " + formattedMsg + "\u001B[0m");
                break;
            default:
                System.out.println("📱 " + formattedMsg);
                break;
        }
    }
    
    private String getDisplayType(int priority) {
        return switch (priority) {
            case 5 -> "achievement";
            case 3, 4 -> "important";
            case 1, 2 -> "normal";
            default -> "low";
        };
    }
    
    private String formatNotification(Notification notif) {
        return String.format("%s: %s", 
            capitalize(notif.type), 
            notif.message.replace("\
", "
")
        );
    }
    
    private void lumenDisplayNotification(String type, String message) {
        // Integration with Lumen OS Wayland notification daemon
        // Target: /lumen-motonexus6/system/graph/mod/system2Dengine.LUMENGUI/core/wayland/notif
        try {
            String lumenNotifPath = "/tmp/lumen_notif_pipe";
            try (FileWriter writer = new FileWriter(lumenNotifPath, true)) {
                writer.write(String.format("TYPE:%s|MSG:%s|TS:%s
",
                    type, message.replace("|", "\\|"), 
                    LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME)));
                writer.flush();
            }
        } catch (IOException e) {
            // Fallback to stderr
            System.err.println("[LUMEN] " + type + ": " + message);
        }
    }
    
    private void logNotification(Notification notif) {
        try (FileWriter writer = new FileWriter(NOTIF_LOG_PATH, true)) {
            writer.write(notif.toString() + "
");
        } catch (IOException e) {
            System.err.println("Log write failed: " + e.getMessage());
        }
    }
    
    private void logEvent(String event) {
        try (FileWriter writer = new FileWriter(NOTIF_LOG_PATH, true)) {
            writer.write(String.format("[%s] ENGINE: %s
",
                LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME),
                event));
        } catch (IOException ignored) {}
    }
    
    private void saveNotificationHistory(Notification notif) {
        try (RandomAccessFile raf = new RandomAccessFile(NOTIF_DATA_PATH, "rw")) {
            raf.seek(raf.length());
            raf.writeBytes(gson.toJson(notif) + "
");
        } catch (IOException e) {
            System.err.println("History save failed: " + e.getMessage());
        }
    }
    
    private void loadNotificationHistory() {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(NOTIF_DATA_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                try {
                    Notification notif = gson.fromJson(line, Notification.class);
                    if (notif != null) {
                        notificationQueue.offer(notif);
                    }
                } catch (JsonSyntaxException ignored) {}
            }
        } catch (IOException e) {
            // No history file yet
        }
    }
    
    public void stop() {
        System.out.println("NotifEngine: Shutting down...");
        running.set(false);
        
        if (scheduler != null) {
            scheduler.shutdown();
        }
        
        executorService.shutdown();
        try {
            if (serverChannel != null) {
                serverChannel.close();
            }
            Files.deleteIfExists(Paths.get(SOCKET_PATH));
        } catch (IOException e) {
            System.err.println("Cleanup failed: " + e.getMessage());
        }
        
        logEvent("NotifEngine stopped");
    }
    
    private String capitalize(String str) {
        if (str == null || str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
    
    public static void main(String[] args) {
        NotifEngine engine = new NotifEngine();
        
        Runtime.getRuntime().addShutdownHook(new Thread(engine::stop));
        
        engine.start();
        
        // Keep alive
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        
        engine.stop();
    }
}
